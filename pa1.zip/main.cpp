// main.cpp
#include "tree.h"

int main(int argc, char * argv[]) {
    // Expected:
    // argv[1] = time constraint (double)
    // argv[2] = inverter param file
    // argv[3] = wire param file
    // argv[4] = input RC tree (post-order text)
    // argv[5] = out1: pre-order text
    // argv[6] = out2: elmore (binary)
    // argv[7] = out3: ttopo (text)  -- will be empty for now
    // argv[8] = out4: btopo (binary) -- will be empty for now
    if (argc < 6) return EXIT_FAILURE;

    // const double T_max = atof(argv[1]);

    FILE * invIn  = fopen(argv[2], "r");
    FILE * wireIn = fopen(argv[3], "r");
    FILE * topIn  = fopen(argv[4], "r");
    if (!invIn || !wireIn || !topIn) {
        if (invIn)  fclose(invIn);
        if (wireIn) fclose(wireIn);
        if (topIn)  fclose(topIn);
        return EXIT_FAILURE;
    }

    
    Node * root = buildTree(topIn);
    fclose(topIn);
    if (!root) {
        fclose(invIn);
        fclose(wireIn);
        return EXIT_FAILURE;
    }
    // topIn = fopen(argv[4], "r");
    // Node* original_root = buildTree(topIn);
    // fclose(topIn);

    FILE * preOut    = fopen(argv[5], "w");   
    FILE * elmoreOut = fopen(argv[6], "wb");  
    FILE * ttopoOut  = fopen(argv[7], "w");   
    FILE * btopoOut  = fopen(argv[8], "wb"); 

    if (!preOut || !elmoreOut || !ttopoOut || !btopoOut) {
        if (preOut)    fclose(preOut);
        if (elmoreOut) fclose(elmoreOut);
        if (ttopoOut)  fclose(ttopoOut);
        if (btopoOut)  fclose(btopoOut);
        delete root;
        fclose(invIn);
        fclose(wireIn);
        return EXIT_FAILURE;
    }
    preorder(root, preOut);
    fclose(preOut);
    char buf[256];
    double C_in = 0.0, C_out = 0.0, R_inv = 0.0;
    if (fgets(buf, sizeof(buf), invIn)) {
        sscanf(buf, "%le %le %le\n", &C_in, &C_out, &R_inv);
    }
    double r = 0.0, c = 0.0;
    if (fgets(buf, sizeof(buf), wireIn)) {
        sscanf(buf, "%le %le\n", &r, &c);
    }
    // fprintf(stderr, "Inverter params: C_in=%.2le, C_out=%.2le, R_inv=%.2le\n", C_in, C_out, R_inv);
    // fprintf(stderr, "Wire params: r=%.2le, c=%.2le\n", r, c);
    fclose(invIn);
    fclose(wireIn);
    build_c_prime_iter(root, C_out, c, /*is_root=*/true);
    iter_downstream(root);
    iter_delay(root, R_inv, r, elmoreOut);
    fclose(elmoreOut);

    
    double Tb = R_inv * C_out;
    // fprintf(stderr, "Inverter intrinsic delay Tb=Rb*C_out=%.2le\n", Tb);

    try {
        bool feasible = inverter_insertion(root, atof(argv[1]), R_inv, r, c, C_out, C_in, Tb);
        // fprintf(stderr, "Inverter insertion %sfeasible under T=%.3f s\n", 
        //         feasible ? "" : "not ", atof(argv[1]));
        // printf("Writing modified tree to %s and %s\n", argv[7], argv[8]);
        
        clear_computed_fields(root);
        build_c_prime_iter(root, C_out, c, /*is_root=*/true);
        iter_downstream(root);


        postorder_with_inverters(root,ttopoOut);
        fclose(ttopoOut);
        postorder_with_inverters_binary(root,btopoOut);
        fclose(btopoOut);
        // //open the ttopo to verify
        // FILE* ttopoIn = fopen(argv[7],"r");
        // if(!ttopoIn){
        //     std::cerr << "Error opening ttopo for verification." << std::endl;
        //     delete root;
        //     delete original_root;
        //     return EXIT_FAILURE;
        // }
        // Node* ttopo_root = buildTreeWithInverters(ttopoIn);
        // build_c_prime_iter(ttopo_root, C_out, c, /*is_root=*/true);
        // iter_downstream(ttopo_root);
        // fclose(ttopoIn);

        // verify_solution(original_root, root, ttopo_root, R_inv,r,c,C_out,C_in,Tb,atof(argv[1]), argv[4]);
        // delete ttopo_root;
        delete root;
        // delete original_root;
        if (!feasible) {
            return EXIT_FAILURE;
        }
        return EXIT_SUCCESS;
    } catch (...) {
        std::cerr << "Error during inverter insertion." << std::endl;
        postorder_with_inverters(root,ttopoOut);
        fclose(ttopoOut);
        postorder_with_inverters_binary(root,btopoOut);
        fclose(btopoOut);
        // delete original_root;
        delete root;
        return EXIT_FAILURE;
        
    }
    
    // postorder_with_inverters(root,ttopoOut);
    // fclose(ttopoOut);
    // postorder_with_inverters_binary(root,btopoOut);
    // fclose(btopoOut);
    delete root;
    // delete original_root;
    return EXIT_SUCCESS;
}
